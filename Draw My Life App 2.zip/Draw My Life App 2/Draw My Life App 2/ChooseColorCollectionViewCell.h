//
//  ChooseColorCollectionViewCell.h
//  Draw My Life App 2
//
//  Created by Owner on 2/21/16.
//  Copyright © 2016 Josh Akins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseColorCollectionViewCell : UICollectionViewCell

@end
