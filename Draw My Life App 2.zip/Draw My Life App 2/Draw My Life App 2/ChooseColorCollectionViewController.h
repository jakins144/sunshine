//
//  ChooseColorCollectionViewController.h
//  Draw My Life App 2
//
//  Created by Owner on 2/21/16.
//  Copyright © 2016 Josh Akins. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChooseColorCollectionViewCell.h"
#import "RecordDrawingViewController.h"

@interface ChooseColorCollectionViewController : UICollectionViewController
@property (strong,nonatomic) NSMutableArray *colorArray;

@end
