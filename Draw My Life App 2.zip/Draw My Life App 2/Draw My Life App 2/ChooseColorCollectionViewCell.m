//
//  ChooseColorCollectionViewCell.m
//  Draw My Life App 2
//
//  Created by Owner on 2/21/16.
//  Copyright © 2016 Josh Akins. All rights reserved.
//

#import "ChooseColorCollectionViewCell.h"

@implementation ChooseColorCollectionViewCell

@end
